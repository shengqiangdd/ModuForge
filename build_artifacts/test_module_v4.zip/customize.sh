#!/system/bin/sh
# Install script