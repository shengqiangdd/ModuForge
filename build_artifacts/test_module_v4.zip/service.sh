#!/system/bin/sh
# Service script