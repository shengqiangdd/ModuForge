#!/system/bin/sh
# Install