#!/system/bin/sh
# Service