/**
 * AndroBoost-SmartTune - 前端交互逻辑
 * 功能：深色模式、告警系统、应用策略中心、调参实验室、LocalStorage 持久化
 */
(function () {
    'use strict';

    // =============================================
    // 常量 & 默认值
    // =============================================
    const STORAGE_KEYS = {
        THEME:            'abst_theme',
        GLOBAL_STRATEGY:  'abst_global_strategy',
        APP_STRATEGIES:   'abst_app_strategies',
        ALPHA:            'abst_alpha',
        TEMP_THRESHOLD:   'abst_temp_threshold',
        POWER_THRESHOLD:  'abst_power_threshold',
    };

    const STRATEGY_INFO = {
        powersave:   { label: '省电', icon: '🔋', desc: '省电模式：最大限度降低CPU频率，延长续航' },
        balanced:    { label: '均衡', icon: '⚖️', desc: '均衡模式：在性能和功耗之间取得平衡' },
        performance: { label: '性能', icon: '🚀', desc: '性能模式：提升CPU频率，获得最佳性能' },
        thermal:     { label: '散热', icon: '❄️', desc: '散热模式：优先降低温度，防止过热降频' },
        extreme:     { label: '极限', icon: '🔥', desc: '极限模式：释放全部性能，注意散热和功耗' },
    };

    const DEFAULTS = {
        alpha: 0.30,
        tempThreshold: 50,
        powerThreshold: 4000,
    };

    // 模拟监控数据（实际使用时替换为真实接口）
    let monitorData = {
        cpuTemp: 38,
        cpuFreq: 1800,
        power: 2100,
        cpuUsage: 45,
    };

    // =============================================
    // 工具函数
    // =============================================
    function $(sel) { return document.querySelector(sel); }
    function $$(sel) { return document.querySelectorAll(sel); }

    function load(key, fallback) {
        try {
            const v = localStorage.getItem(key);
            return v !== null ? JSON.parse(v) : fallback;
        } catch { return fallback; }
    }

    function save(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    // =============================================
    // 1. 深色模式切换
    // =============================================
    function initTheme() {
        const saved = load(STORAGE_KEYS.THEME, 'light');
        applyTheme(saved);
    }

    function applyTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        const btn = $('#theme-toggle');
        btn.textContent = theme === 'dark' ? '☀️' : '🌙';
        btn.title = theme === 'dark' ? '切换到浅色模式' : '切换到深色模式';
        save(STORAGE_KEYS.THEME, theme);
    }

    function toggleTheme() {
        const current = document.documentElement.getAttribute('data-theme');
        applyTheme(current === 'dark' ? 'light' : 'dark');
    }

    // =============================================
    // 2. 全局策略
    // =============================================
    function initGlobalStrategy() {
        const saved = load(STORAGE_KEYS.GLOBAL_STRATEGY, 'balanced');
        setActiveStrategy(saved);

        $('#strategy-selector').addEventListener('click', function (e) {
            const btn = e.target.closest('.strategy-btn');
            if (!btn) return;
            const strategy = btn.dataset.strategy;
            setActiveStrategy(strategy);
            save(STORAGE_KEYS.GLOBAL_STRATEGY, strategy);
        });
    }

    function setActiveStrategy(strategy) {
        $$('.strategy-btn').forEach(function (btn) {
            btn.classList.toggle('active', btn.dataset.strategy === strategy);
        });
        const info = STRATEGY_INFO[strategy] || STRATEGY_INFO.balanced;
        $('#strategy-desc').textContent = info.desc;
    }

    // =============================================
    // 3. 应用策略中心
    // =============================================
    function initAppStrategies() {
        renderAppTable();
        setupModal();
    }

    function getAppStrategies() {
        return load(STORAGE_KEYS.APP_STRATEGIES, []);
    }

    function setAppStrategies(list) {
        save(STORAGE_KEYS.APP_STRATEGIES, list);
    }

    function renderAppTable() {
        const list = getAppStrategies();
        const tbody = $('#app-table-body');

        if (list.length === 0) {
            tbody.innerHTML = '<tr><td colspan="4" class="empty-row">暂无应用策略，点击"添加应用"开始配置</td></tr>';
            return;
        }

        tbody.innerHTML = list.map(function (app, idx) {
            const info = STRATEGY_INFO[app.strategy] || STRATEGY_INFO.balanced;
            return '<tr>' +
                '<td><code>' + escapeHtml(app.packageName) + '</code></td>' +
                '<td>' + escapeHtml(app.appName) + '</td>' +
                '<td><span class="strategy-badge badge-' + app.strategy + '">' + info.icon + ' ' + info.label + '</span></td>' +
                '<td><button class="btn-remove" data-index="' + idx + '">删除</button></td>' +
            '</tr>';
        }).join('');

        // 绑定删除
        tbody.querySelectorAll('.btn-remove').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var idx = parseInt(this.dataset.index, 10);
                var list = getAppStrategies();
                list.splice(idx, 1);
                setAppStrategies(list);
                renderAppTable();
            });
        });
    }

    function setupModal() {
        var modal = $('#app-modal');

        $('#add-app-btn').addEventListener('click', function () {
            modal.style.display = 'flex';
            $('#app-package').value = '';
            $('#app-name').value = '';
            $('#app-strategy').value = 'balanced';
            $('#app-package').focus();
        });

        $('#modal-close').addEventListener('click', closeModal);
        $('#modal-cancel').addEventListener('click', closeModal);

        modal.addEventListener('click', function (e) {
            if (e.target === modal) closeModal();
        });

        $('#modal-confirm').addEventListener('click', function () {
            var packageName = $('#app-package').value.trim();
            var appName = $('#app-name').value.trim();
            var strategy = $('#app-strategy').value;

            if (!packageName) {
                shakeInput($('#app-package'));
                return;
            }
            if (!appName) {
                shakeInput($('#app-name'));
                return;
            }

            var list = getAppStrategies();
            // 检查重复
            var exists = list.some(function (a) { return a.packageName === packageName; });
            if (exists) {
                shakeInput($('#app-package'));
                return;
            }

            list.push({ packageName: packageName, appName: appName, strategy: strategy });
            setAppStrategies(list);
            renderAppTable();
            closeModal();
        });
    }

    function closeModal() {
        $('#app-modal').style.display = 'none';
    }

    function shakeInput(el) {
        el.style.borderColor = 'var(--danger)';
        el.style.animation = 'shake 0.4s ease';
        setTimeout(function () {
            el.style.borderColor = '';
            el.style.animation = '';
        }, 500);
    }

    function escapeHtml(str) {
        var div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    // =============================================
    // 4. 调参实验室
    // =============================================
    function initParamLab() {
        var slider = $('#alpha-slider');
        var numberInput = $('#alpha-input');
        var tempInput = $('#temp-threshold');
        var powerInput = $('#power-threshold');

        // 加载保存的值
        slider.value = Math.round(load(STORAGE_KEYS.ALPHA, DEFAULTS.alpha) * 100);
        numberInput.value = parseFloat(load(STORAGE_KEYS.ALPHA, DEFAULTS.alpha)).toFixed(2);
        tempInput.value = load(STORAGE_KEYS.TEMP_THRESHOLD, DEFAULTS.tempThreshold);
        powerInput.value = load(STORAGE_KEYS.POWER_THRESHOLD, DEFAULTS.powerThreshold);

        // 滑块 <-> 数字输入联动
        slider.addEventListener('input', function () {
            var val = parseInt(this.value, 10);
            numberInput.value = (val / 100).toFixed(2);
        });

        numberInput.addEventListener('input', function () {
            var val = parseFloat(this.value);
            if (!isNaN(val)) {
                slider.value = Math.round(val * 100);
            }
        });

        // 保存
        $('#save-params-btn').addEventListener('click', function () {
            var alpha = parseFloat(numberInput.value);
            if (isNaN(alpha) || alpha < 0 || alpha > 1) alpha = DEFAULTS.alpha;

            var temp = parseInt(tempInput.value, 10);
            if (isNaN(temp) || temp < 30 || temp > 90) temp = DEFAULTS.tempThreshold;

            var power = parseInt(powerInput.value, 10);
            if (isNaN(power) || power < 1000 || power > 10000) power = DEFAULTS.powerThreshold;

            save(STORAGE_KEYS.ALPHA, alpha);
            save(STORAGE_KEYS.TEMP_THRESHOLD, temp);
            save(STORAGE_KEYS.POWER_THRESHOLD, power);

            showToast('参数已保存 ✓');
        });

        // 重置
        $('#reset-params-btn').addEventListener('click', function () {
            slider.value = Math.round(DEFAULTS.alpha * 100);
            numberInput.value = DEFAULTS.alpha.toFixed(2);
            tempInput.value = DEFAULTS.tempThreshold;
            powerInput.value = DEFAULTS.powerThreshold;
            save(STORAGE_KEYS.ALPHA, DEFAULTS.alpha);
            save(STORAGE_KEYS.TEMP_THRESHOLD, DEFAULTS.tempThreshold);
            save(STORAGE_KEYS.POWER_THRESHOLD, DEFAULTS.powerThreshold);
            showToast('已重置为默认参数');
        });
    }

    // =============================================
    // 5. 告警系统
    // =============================================
    var activeAlerts = [];

    function checkAlerts() {
        var tempThreshold = load(STORAGE_KEYS.TEMP_THRESHOLD, DEFAULTS.tempThreshold);
        var powerThreshold = load(STORAGE_KEYS.POWER_THRESHOLD, DEFAULTS.powerThreshold);
        var temp = monitorData.cpuTemp;
        var power = monitorData.power;

        var newAlerts = [];

        if (temp > tempThreshold) {
            newAlerts.push({
                id: 'temp_high',
                type: 'danger',
                message: '⚠️ CPU温度过高！当前 ' + temp + '°C，阈值 ' + tempThreshold + '°C',
            });
        }

        if (power > powerThreshold) {
            newAlerts.push({
                id: 'power_high',
                type: 'warning',
                message: '⚡ 功耗过高！当前 ' + power + ' mW，阈值 ' + powerThreshold + ' mW',
            });
        }

        // 合并已有（保留用户手动关闭的）
        var dismissed = activeAlerts.filter(function (a) { return a.dismissed; });
        activeAlerts = newAlerts.concat(dismissed.filter(function (d) {
            return !newAlerts.some(function (n) { return n.id === d.id; });
        }));

        renderAlerts();
    }

    function renderAlerts() {
        var visible = activeAlerts.filter(function (a) { return !a.dismissed; });
        var section = $('#alert-section');
        var list = $('#alert-list');

        if (visible.length === 0) {
            section.style.display = 'none';
            return;
        }

        section.style.display = 'block';
        list.innerHTML = visible.map(function (alert) {
            return '<div class="alert-item ' + alert.type + '">' +
                '<span>' + alert.message + '</span>' +
                '<button class="alert-dismiss" data-id="' + alert.id + '">&times;</button>' +
            '</div>';
        }).join('');

        list.querySelectorAll('.alert-dismiss').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var id = this.dataset.id;
                var target = activeAlerts.find(function (a) { return a.id === id; });
                if (target) target.dismissed = true;
                renderAlerts();
            });
        });
    }

    // =============================================
    // 6. 实时监控模拟
    // =============================================
    function initMonitor() {
        updateMonitorDisplay();
        $('#refresh-btn').addEventListener('click', simulateMonitorData);
        setInterval(simulateMonitorData, 3000); // 每 3 秒刷新
    }

    function simulateMonitorData() {
        // 模拟波动数据（实际使用时读取真实硬件数据）
        monitorData.cpuTemp  = clamp(35 + Math.random() * 25, 25, 85);
        monitorData.cpuFreq  = Math.round(800 + Math.random() * 1600);
        monitorData.power    = Math.round(1500 + Math.random() * 4000);
        monitorData.cpuUsage = Math.round(10 + Math.random() * 85);

        updateMonitorDisplay();
        checkAlerts();
    }

    function updateMonitorDisplay() {
        var temp  = Math.round(monitorData.cpuTemp);
        var freq  = monitorData.cpuFreq;
        var power = monitorData.power;
        var usage = monitorData.cpuUsage;

        $('#cpu-temp').textContent  = temp + '°C';
        $('#cpu-freq').textContent  = freq + ' MHz';
        $('#power-val').textContent = power + ' mW';
        $('#cpu-usage').textContent = usage + '%';

        // 进度条百分比
        $('#temp-bar').style.width  = clamp(temp / 85 * 100, 0, 100) + '%';
        $('#freq-bar').style.width  = clamp(freq / 2400 * 100, 0, 100) + '%';
        $('#power-bar').style.width = clamp(power / 6000 * 100, 0, 100) + '%';
        $('#usage-bar').style.width = clamp(usage, 0, 100) + '%';
    }

    function clamp(val, min, max) {
        return Math.max(min, Math.min(max, val));
    }

    // =============================================
    // 7. Toast 提示
    // =============================================
    function showToast(message) {
        var existing = $('.toast');
        if (existing) existing.remove();

        var toast = document.createElement('div');
        toast.className = 'toast';
        toast.textContent = message;
        toast.style.cssText = [
            'position: fixed',
            'bottom: 24px',
            'left: 50%',
            'transform: translateX(-50%)',
            'padding: 10px 24px',
            'background: var(--accent)',
            'color: #fff',
            'border-radius: 8px',
            'font-size: 0.9rem',
            'font-weight: 600',
            'box-shadow: 0 4px 12px rgba(0,0,0,0.2)',
            'z-index: 300',
            'animation: fadeIn 0.3s ease',
        ].join(';');

        document.body.appendChild(toast);
        setTimeout(function () {
            toast.style.opacity = '0';
            toast.style.transition = 'opacity 0.3s';
            setTimeout(function () { toast.remove(); }, 300);
        }, 2000);
    }

    // =============================================
    // 8. 全局连接状态模拟
    // =============================================
    function initConnectionStatus() {
        // 模拟连接状态（实际使用时根据 WebSocket/Shell 连接判断）
        var statusEl = $('#nav-status');
        setTimeout(function () {
            statusEl.textContent = '● 已连接';
            statusEl.classList.remove('offline');
            statusEl.classList.add('online');
        }, 1500);
    }

    // =============================================
    // 初始化
    // =============================================
    document.addEventListener('DOMContentLoaded', function () {
        initTheme();
        initGlobalStrategy();
        initAppStrategies();
        initParamLab();
        initMonitor();
        initConnectionStatus();

        // 主题切换按钮
        $('#theme-toggle').addEventListener('click', toggleTheme);

        // 关闭所有告警
        $('#dismiss-alerts').addEventListener('click', function () {
            activeAlerts.forEach(function (a) { a.dismissed = true; });
            renderAlerts();
        });
    });
})();
