#!/bin/bash
echo "=== Build Debug Script ==="
echo "Working directory: $(pwd)"
echo "Date: $(date)"

# Check Rust build
echo ""
echo "=== Rust Build Test ==="
cd /data/storage/projects/1785249992652501794-1864/src/rust

# Set the environment
export RUSTFLAGS="-C target-cpu=generic"
export CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER=/opt/android-ndk/toolchains/llvm/prebuilt/linux-x86_64/bin/aarch64-linux-android21-clang

echo "Rust cargo binary: $(which cargo 2>/dev/null || echo 'not found')"
echo "Rust target: aarch64-linux-android"
echo "Linker exists: $([ -f "$CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER" ] && echo 'yes' || echo 'no')"

# Try to build
cargo build --release --target aarch64-linux-android 2>&1 | head -50

echo ""
echo "=== Check build output ==="
ls -la target/aarch64-linux-android/release/ 2>/dev/null | head -20

echo ""
echo "=== PROJECT_ROOT simulation ==="
SCRIPT_DIR="/data/storage/projects/1785249992652501794-1864/src/rust"
PROJECT_ROOT="${PROJECT_ROOT:-$(cd "$(dirname "$SCRIPT_DIR/build.sh")/../.." && pwd)}"
echo "PROJECT_ROOT = $PROJECT_ROOT"
echo "Binary output would be: $PROJECT_ROOT/system/bin/androst"
ls -la "$PROJECT_ROOT/system/bin/" 2>/dev/null || echo "system/bin/ does not exist"
