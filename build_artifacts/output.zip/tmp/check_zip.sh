#!/bin/bash
if [ -f /data/storage/projects/output.zip ]; then
    unzip -l /data/storage/projects/output.zip
else
    echo "output.zip not found, searching..."
    find /data/storage/projects/ -name "*.zip" -o -name "output*" 2>/dev/null
fi
