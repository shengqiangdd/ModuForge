#!/bin/bash
ls -la /opt/android-ndk/toolchains/llvm/prebuilt/linux-x86_64/bin/ 2>/dev/null | grep aarch64 | head -20 || echo "NDK path not found, trying alternatives..."
# Also check if NDK exists at all
ls -la /opt/android-ndk/ 2>/dev/null || echo "/opt/android-ndk not found"
# Check common NDK locations
find / -name "aarch64-linux-android*-clang" -type f 2>/dev/null | head -10
