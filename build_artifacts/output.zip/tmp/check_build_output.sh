#!/bin/bash
echo "=== Checking build output directories ==="
# Check common build output locations
for dir in /tmp/build_output /data/storage/projects/1785249992652501794-1864/system /tmp/module_output; do
    if [ -d "$dir" ]; then
        echo "--- Found: $dir ---"
        find "$dir" -type f 2>/dev/null
    fi
done

echo ""
echo "=== Looking for output.zip ==="
find /data/storage/projects/ -name "output.zip" -type f 2>/dev/null
find /tmp -name "output.zip" -type f 2>/dev/null

echo ""
echo "=== Looking for androst, andromon, androwui binaries ==="
find /tmp -name "androst" -o -name "andromon" -o -name "androwui" 2>/dev/null
find /data/storage -name "androst" -o -name "andromon" -o -name "androwui" 2>/dev/null

echo ""
echo "=== Checking ZIP contents if found ==="
ZIP=$(find /data/storage/projects/ -name "output.zip" -type f 2>/dev/null | head -1)
if [ -n "$ZIP" ]; then
    echo "Found ZIP: $ZIP"
    unzip -l "$ZIP" 2>/dev/null | grep -E "system/bin|androst|andromon|androwui"
else
    echo "ZIP not found via find, checking /data/storage/projects/output.zip"
    unzip -l /data/storage/projects/output.zip 2>/dev/null || echo "Cannot list ZIP"
fi
